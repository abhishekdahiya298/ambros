define( [ "./selector-sizzle" ], function() {
	"use strict";
} );
